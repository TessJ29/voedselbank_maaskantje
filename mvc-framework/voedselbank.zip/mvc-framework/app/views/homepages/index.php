<?php require APPROOT . '/views/includes/head.php'; ?>
<p>
<h3><?= $data["title"]; ?></h3>
</p>
<a href="<?= URLROOT; ?>/packages">overview pakketten</a> |
<?php require APPROOT . '/views/includes/footer.php'; ?>